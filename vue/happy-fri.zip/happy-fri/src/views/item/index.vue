<template>
  <div class="item_container">
    <itemContainer fatherComponent="item"></itemContainer>
  </div>
</template>

<script>
import itemContainer from '@/components/itemContainer'
export default {
  components: {
    itemContainer
  }
}
</script>

<style>

</style>