<template>
  <div class="home_container">
    <itemContainer fatherComponent="home"></itemContainer>
  </div>
</template>

<script>
import itemContainer from '@/components/itemContainer'
export default {
  components: {
    itemContainer
  }
}
</script>

<style>

</style>